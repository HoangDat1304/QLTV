
package com.mycompany.qlthuvien.entity;

import java.util.Scanner;

/**
 *
 * @author DAT
 */
public class BanDoc {
    String  hoTen ,diaChi , loaiBanDoc;
    int SĐT , ma , number=10000;
    int id = number++;
    
    

    public BanDoc(String hoTen, String diaChi, String loaiBanDoc, int SĐT, int ma) {
        this.id = id;
        this.hoTen = hoTen;
        this.diaChi = diaChi;
        this.loaiBanDoc = loaiBanDoc;
        this.SĐT = SĐT;
        this.ma = ma;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public String getLoaiBanDoc() {
        return loaiBanDoc;
    }

    public void setLoaiBanDoc(String loaiBanDoc) {
        this.loaiBanDoc = loaiBanDoc;
    }

    public int getSĐT() {
        return SĐT;
    }

    public void setSĐT(int SĐT) {
        this.SĐT = SĐT;
    }

    public int getMa() {
        return ma;
    }

    public void setMa(int ma) {
        this.ma = ma;
    }

   public void Nhap(){
       Scanner sc = new Scanner(System.in);
        
       System.out.println("moi nhap ho ten :");
       hoTen = sc.nextLine();
       System.out.println("moi nhap dia chi :");
       diaChi = sc.nextLine();
       System.out.println("moi nhap SDT :");
       SĐT = sc.nextInt();
       System.out.println("moi nhap loai ban doc :");
       loaiBanDoc = sc.nextLine();

       if (loaiBanDoc == null || loaiBanDoc.equals("sinh vien") || loaiBanDoc.equals("sv cao hoc") || loaiBanDoc.equals("giao vien")) {

       }
   }
   public void Xuat(){
       System.out.printf("ma: %s - ho ten: %s - dia chi: %s  - sdt: %s - loai ban doc: %s", ma , hoTen,diaChi ,SĐT , loaiBanDoc);
        
    }   
    
    
    
    
    
}
